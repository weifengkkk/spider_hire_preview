create definer = root@localhost view salaryforcity as
select `spiderdatabase`.`handled_data`.`city` AS `city`, `spiderdatabase`.`handled_data`.`avg_salary` AS `salary`
from `spiderdatabase`.`handled_data`;

-- comment on column salaryforcity.city not supported: 城市

-- comment on column salaryforcity.salary not supported: 平均工资

