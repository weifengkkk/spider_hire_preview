create definer = root@localhost view experienceforsalary as
select `spiderdatabase`.`handled_data`.`min_salary` AS `min_salary`,
       `spiderdatabase`.`handled_data`.`max_salary` AS `max_salary`,
       `spiderdatabase`.`handled_data`.`avg_salary` AS `avg_salary`,
       `spiderdatabase`.`handled_data`.`experience` AS `experience`
from `spiderdatabase`.`handled_data`;

-- comment on column experienceforsalary.min_salary not supported: 最小工资

-- comment on column experienceforsalary.max_salary not supported: 最大工资

-- comment on column experienceforsalary.avg_salary not supported: 平均工资

-- comment on column experienceforsalary.experience not supported: 经验

