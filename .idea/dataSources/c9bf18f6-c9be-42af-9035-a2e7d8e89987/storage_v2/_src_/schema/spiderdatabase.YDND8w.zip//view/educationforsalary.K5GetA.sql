create definer = root@localhost view educationforsalary as
select `spiderdatabase`.`handled_data`.`education`  AS `edu`,
       `spiderdatabase`.`handled_data`.`min_salary` AS `min`,
       `spiderdatabase`.`handled_data`.`max_salary` AS `max`,
       `spiderdatabase`.`handled_data`.`avg_salary` AS `avg`
from `spiderdatabase`.`handled_data`;

-- comment on column educationforsalary.edu not supported: 学历

-- comment on column educationforsalary.min not supported: 最小工资

-- comment on column educationforsalary.max not supported: 最大工资

-- comment on column educationforsalary.avg not supported: 平均工资

