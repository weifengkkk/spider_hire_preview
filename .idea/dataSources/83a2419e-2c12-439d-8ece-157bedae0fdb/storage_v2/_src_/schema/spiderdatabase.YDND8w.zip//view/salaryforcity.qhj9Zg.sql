create definer = root@localhost view salaryforcity as
select `spiderdatabase`.`handled_data`.`city` AS `city`, `spiderdatabase`.`handled_data`.`avg_salary` AS `salary`
from `spiderdatabase`.`handled_data`;

