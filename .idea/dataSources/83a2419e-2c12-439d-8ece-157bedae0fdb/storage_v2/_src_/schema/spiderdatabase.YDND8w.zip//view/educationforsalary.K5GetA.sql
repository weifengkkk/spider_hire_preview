create definer = root@localhost view educationforsalary as
select `spiderdatabase`.`handled_data`.`education`  AS `edu`,
       `spiderdatabase`.`handled_data`.`min_salary` AS `min`,
       `spiderdatabase`.`handled_data`.`max_salary` AS `max`,
       `spiderdatabase`.`handled_data`.`avg_salary` AS `avg`
from `spiderdatabase`.`handled_data`;

