create definer = root@localhost view experienceforsalary as
select `spiderdatabase`.`handled_data`.`min_salary` AS `min_salary`,
       `spiderdatabase`.`handled_data`.`max_salary` AS `max_salary`,
       `spiderdatabase`.`handled_data`.`avg_salary` AS `avg_salary`,
       `spiderdatabase`.`handled_data`.`experience` AS `experience`
from `spiderdatabase`.`handled_data`;

